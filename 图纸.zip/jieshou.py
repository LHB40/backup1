import socket
import time

#socket.setdefaulttimeout(2)
while 1:
    try:
        so=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        so.bind(('127.0.0.1',6000))
        so.listen(5)
        so1=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        so1.bind(('127.0.0.1',6001))
        so1.listen(5)
        con1,st=so1.accept()
        con,st=so.accept()
        path=con1.recv(1024)
        path=path.decode('utf-8')
        path+=r".pj"
        print(path)
        txt=open(path,'wb')
        while 1:
            get=con.recv(10240)
            txt.write(get)
            if len(get)<10240:
                break
        txt.flush()
        txt.close()
        con1.close()
        so1.close()
        con.close()
        so.close()
    except:
        print(1)
        pass
